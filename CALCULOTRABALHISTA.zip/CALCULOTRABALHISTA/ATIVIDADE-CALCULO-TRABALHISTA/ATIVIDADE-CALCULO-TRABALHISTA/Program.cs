﻿using System;
using System.Globalization;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\n=== CÁLCULO TRABALHISTA ===");

            Console.Write("Informe o valor da hora (0 para sair): R$ ");
            if (!double.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out double valorHora) || valorHora == 0)
                break;

            Console.Write("Quantidade de horas trabalhadas: ");
            double horas = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            Console.Write("Deseja Vale-Transporte? (S/N): ");
            char vt = Char.ToUpper(Console.ReadKey().KeyChar);
            Console.WriteLine();

            Console.Write("Outras deduções (R$): ");
            double outrasDeducoes = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            double salarioBruto = valorHora * horas;
            double descontoINSS = CalcularINSS(salarioBruto);
            double baseIRPF = salarioBruto - descontoINSS;
            double descontoIRPF = CalcularIRPF(baseIRPF);
            double descontoVT = (vt == 'S') ? salarioBruto * 0.06 : 0.0;
            double salarioLiquido = salarioBruto - descontoINSS - descontoIRPF - descontoVT - outrasDeducoes;

            Console.WriteLine("\n=== CÁLCULO TRABALHISTA ===");
            Console.WriteLine($"Salário Bruto            R$ {salarioBruto:F2}");
            Console.WriteLine($"Desconto INSS            - R$ {descontoINSS:F2}");
            Console.WriteLine($"Desconto IRPF            - R$ {descontoIRPF:F2}");
            Console.WriteLine($"Desconto Vale Transporte - R$ {descontoVT:F2}");
            Console.WriteLine($"Outras Deduções          - R$ {outrasDeducoes:F2}");
            Console.WriteLine($"Salário Líquido          R$ {salarioLiquido:F2}");
        }
    }

    static double CalcularINSS(double salario)
    {
        double total = 0;

        if (salario > 3856.94)
        {
            total += (Math.Min(salario, 7507.49) - 3856.95) * 0.14;
            salario = 3856.94;
        }
        if (salario > 2571.30)
        {
            total += (Math.Min(salario, 3856.94) - 2571.30) * 0.12;
            salario = 2571.30;
        }
        if (salario > 1320.00)
        {
            total += (Math.Min(salario, 2571.29) - 1320.01) * 0.09;
            salario = 1320.00;
        }
        if (salario > 0)
        {
            total += salario * 0.075;
        }

        return total;
    }

    static double CalcularIRPF(double baseIR)
    {
        
        if (baseIR <= 2112.00)
            return 0.0;
        else if (baseIR <= 2826.65)
            return baseIR * 0.075 - 158.40;
        else if (baseIR <= 3751.05)
            return baseIR * 0.15 - 370.40;
        else if (baseIR <= 4664.68)
            return baseIR * 0.225 - 651.73;
        else
            return baseIR * 0.275 - 884.96;
    }
}