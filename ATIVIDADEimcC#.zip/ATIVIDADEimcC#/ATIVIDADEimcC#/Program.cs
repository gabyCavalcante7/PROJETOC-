﻿using System;
using System.Globalization;

class Program
{
    static void Main()
    {
        Console.WriteLine("=== Cálculo do IMC ===");

        Console.Write("Nome: ");
        string nome = Console.ReadLine();

        Console.Write("Sexo (M/F): ");
        char sexo = Char.ToUpper(Console.ReadKey().KeyChar);
        Console.WriteLine();

        Console.Write("Peso (kg): ");
        if (!double.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out double peso))
        {
            Console.WriteLine("Peso inválido!");
            return;
        }

        Console.Write("Altura (m): ");
        if (!double.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out double altura))
        {
            Console.WriteLine("Altura inválida!");
            return;
        }

        double imc = peso / (altura * altura);
        Console.WriteLine($"\n{nome}, seu IMC é {imc:F2}");

        string condicao = "";
        double minNormal = 0, maxNormal = 0;

        if (sexo == 'F')
        {
            if (imc < 19.1) condicao = "Abaixo do peso";
            else if (imc <= 25.8) condicao = "No peso normal";
            else if (imc <= 27.3) condicao = "Marginalmente acima do peso";
            else if (imc <= 32.3) condicao = "Acima do peso ideal";
            else condicao = "Obeso";

            minNormal = 19.1;
            maxNormal = 25.8;
        }
        else if (sexo == 'M')
        {
            if (imc < 20.7) condicao = "Abaixo do peso";
            else if (imc <= 26.4) condicao = "No peso normal";
            else if (imc <= 27.8) condicao = "Marginalmente acima do peso";
            else if (imc <= 31.1) condicao = "Acima do peso ideal";
            else condicao = "Obeso";

            minNormal = 20.7;
            maxNormal = 26.4;
        }
        else
        {
            Console.WriteLine("Sexo inválido! Use 'M' ou 'F'.");
            return;
        }

        Console.WriteLine($"Condição corporal: {condicao}");

        if (condicao != "No peso normal")
        {
            double pesoMin = minNormal * altura * altura;
            double pesoMax = maxNormal * altura * altura;

            if (imc < minNormal)
            {
                double ganhar = pesoMin - peso;
                Console.WriteLine($"Você deve ganhar pelo menos {ganhar:F2} kg para alcançar o peso normal.");
            }
            else
            {
                double perder = peso - pesoMax;
                Console.WriteLine($"Você deve perder pelo menos {perder:F2} kg para alcançar o peso normal.");
            }
        }
    }
}
